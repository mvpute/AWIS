#include "CPTake.h"
extern User *userCurrent;

CPTake::CPTake(int winX,int winY,int winWidth,int winHeight)
	:CWindow(winX,winY,winWidth,winHeight)
{
	this->lab1 = new CLabel(LABEL,43,6,0,0,"��ӭʹ�òֿ��̵��ϵͳ");

	this->btn1 = new CButton(BUTTON,30,13,18,3,"�½��̵�[1]");
	this->btn2 = new CButton(BUTTON,60,13,18,3,"�̵��¼[2]");
	this->btn3 = new CButton(BUTTON,30,18,18,3,"����[Esc]");

	this->addControl(lab1);// 0
	this->addControl(btn1);// 1
	this->addControl(btn2);// 2
	this->addControl(btn3);// 3

}
CPTake::~CPTake()
{

}

int CPTake::doaction()
{
	if(flag == -1)
	{
		return 0; // ����ESC�˳������
	}
	else if(flag == 1)
	{
		return 13;
	}
	else if(flag == 2)
	{
		return 15;
	}
	else if(flag == 3)
	{
		return 4;
	}
	return -1;

}
