#ifndef CPREVERSALONE_H
#define CPREVERSALONE_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "Product.h"
#include <string.h>
#include <vector>
#include <map>
#include <time.h>
#include "CFileP.h"
#include "CFilePR.h"
#include "CPRecord.h"

class CPReversalone : public CWindow
{
	public:
		CPReversalone(int winX,int winY,int winWidth,int winHeight);
		~CPReversalone();
		void resetGlobalVars();
		int doaction();
		void paintWindow();
		int LittleWin();
		void showCheck();
		void winRun();
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *lab3;
		CControl *lab4;
		CControl *lab5;
		CControl *lab6;
		CControl *lab7;
		CControl *edit1;
		CControl *edit2;

		CControl *btn1;
		CControl *btn2;
		CControl *btn3;
		CControl *btn4;
		CControl *btn5;
		CControl *btn6;
		CControl *btn7;

};






#endif
