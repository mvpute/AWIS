#ifndef CMCHECK_H
#define CMCHECK_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "User.h"
#include "Product.h"
#include <string.h> 
#include <vector> 
#include <fstream>   // �ļ���д
#include <ctime>

using namespace std;


extern User *userCurrent;
extern vector<User*>* uservec;
extern vector<Product*> * Pdvec;


class CMCheck : public CWindow
{
	private:
		CControl* lab1;
		CControl* lab2;
		CControl* lab3;
		CControl* edit1;
		CControl* btn1;
		CControl* btn2;
		CControl* btn3;


	public:

		CMCheck(int winX, int winY, int winWidth, int winHeight);
		~CMCheck();
		void paintWindow() override;  
		void winRun();
		void showCMCheck();
		string getCurrentDate();
		int doaction();
};

#endif

