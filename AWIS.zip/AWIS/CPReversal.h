#ifndef CPREVERSAL_H
#define CPREVERSAL_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "Product.h"
#include <string.h>
#include <vector>
#include <map>
#include <time.h>
#include "CFileP.h"
#include "CPRecord.h"
#include "CFilePR.h" 

#include <io.h>   // ���� _findfirst��_findnext��_findclose���ļ����ң�

class CPReversal : public CWindow
{
	public:
		CPReversal(int winX,int winY,int winWidth,int winHeight);
		~CPReversal();

		int doaction();
		void paintWindow();
		void winRun();
		void readInventoryFiles(const string& folderPath, vector<string>& taskNums, vector<string>& taskStats); 
	private:
		CControl *lab1;
		CControl *lab2;

		CControl *btn1;
		CControl *btn2;
		CControl *btn3;
		CControl *btn4;

};






#endif
