#ifndef CMSTOCKIN_H
#define CMSTOCKIN_H

#include "CWindow.h"
#include <stdlib.h>

class CMStockin : public CWindow
{
	public:
		CMStockin(int winX,int winY,int winWidth,int winHeight);
		~CMStockin();

		int doaction();
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *btn1;
		CControl *btn2;
		CControl *btn3;

};






#endif
