#ifndef CPCHECK_H
#define CPCHECK_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "User.h"
#include "Product.h"
#include <string.h> 
#include <vector> 
#include <fstream>   // �ļ���д
#include <ctime>
using namespace std;


extern User *userCurrent;
extern vector<User*>* uservec;
extern vector<Product*> * Pdvec;


class CPCheck : public CWindow
{
	private:
		CControl* lab1;
		CControl* lab2;
		CControl* lab3;
		CControl* edit1;
		CControl* btn1;
		CControl* btn2;
		CControl* btn3;


	public:

		CPCheck(int winX, int winY, int winWidth, int winHeight);
		~CPCheck();
		void paintWindow() override;  
		void winRun();
		void showCPCheck();
		string getCurrentDate();
		int doaction();
};

#endif

