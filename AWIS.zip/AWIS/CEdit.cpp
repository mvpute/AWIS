#include "CEdit.h"

CEdit::CEdit(int type,int x,int y,int width,int height,const char *context,int maxLength,int inputType,int status, bool isDraw)
	:CControl(type,x,y,width,height,context,isDraw)
{
	this->maxLength=maxLength;
	this->inputType=inputType;
	this->status=status;
}
CEdit::~CEdit()
{

}
void CEdit::showControl()
{
	CTool::paintBorder(this->x,this->y,this->width,this->height);

	// ��ʾ��������
	CTool::gotoxy(this->x+3, this->y + 1);

	if (strlen(this->context) > 0)
	{
		if (this->status == 0)
		{
			for (int i = 0; i < strlen(this->context); i++)
			{
				putch('*');
			}
		}
		else
		{
			printf("%s", this->context);
		}
	}
}
void CEdit::inputControl(int key)
{
	int count;
	if(key=='\r')
	{
		return;
	}

	// �ַ����������Ѿ�������ַ�����
	count = strlen(this->context);
	// ����Ѿ�������ַ����� =  ���������ֵ����ʱ����������ɾ�����������ַ�������
	if(count >= this->maxLength)
	{
		if(key == '\b'&& count>0)
		{
			// ֧�����ĵ����ͣ�4��5��6���˸���Ҫɾ�������ַ�
			if(this->inputType == 4 || this->inputType == 5 || this->inputType == 6)
			{
				this->context[ -- count] = '\0';
				this->context[ -- count] = '\0';
				printf("\b \b");
				printf("\b \b");
			}
			else
			{
				count--;
				this->context[count]='\0';
				printf("\b \b");
			}
		}
	}
	else
	{
		if(key == '\b' && count>0)
		{
			// ֧�����ĵ����ͣ�4��5��6���˸���Ҫɾ�������ַ�
			if(this->inputType == 4 || this->inputType == 5 || this->inputType == 6)
			{
				this->context[ -- count] = '\0';
				this->context[ -- count] = '\0';
				printf("\b \b");
				printf("\b \b");
			}
			else
			{
				count--;
				this->context[count]='\0';
				printf("\b \b");

			}
		}
		else
		{
			if(this->inputType == 1)
			{
				if((key>='0'&& key<='9') || key == '.' )
				{
					this->context[count++]=key;
					this->context[count]='\0';
					if(this->status==0)
					{
						putch('*');
					}
					else if(this->status==1)
					{
						putch(key);
					}
				}
			}
			else if(this->inputType == 2)
			{
				if((key>='a'&&key<='z')||(key>='A'&&key<='Z'))
				{
					this->context[count++]=key;
					this->context[count]='\0';
					if(this->status==0)
					{
						putch('*');
					}
					else if(this->status==1)
					{
						putch(key);
					}
				}
			}
			else if(this->inputType == 3)
			{
				if((key>='a'&&key<='z')||(key>='A'&&key<='Z')||(key>='0'&& key<='9' )|| (key == '.') )
				{
					this->context[count++]=key;
					this->context[count]='\0';
					if(this->status==0)
					{
						putch('*');
					}
					else if(this->status==1)
					{
						putch(key);
					}
				}
			}
			else if(this->inputType == 4)
			{
				if((unsigned char)key>=0XA1 && (unsigned char)key <= 0XFE)
				{
					char ch2 = getch();
					if ((unsigned char)ch2>=0XA1 && (unsigned char)ch2 <= 0XFE)
					{
						this->context[count++]=key;
						this->context[count++]=ch2;
						this->context[count]='\0';
						if(this->status == 0)
						{
							putch('*');
						}
						else if(this->status == 1)
						{
							printf("%c%c",key,ch2);
						}
					}
				}
			}
			// inputType==5��֧�����ĺ�Ӣ��
			else if(this->inputType == 5)
			{
				// ����˫�ֽ��ַ�
				if((unsigned char)key>=0XA1 && (unsigned char)key <= 0XFE)
				{
					char ch2 = getch();
					if ((unsigned char)ch2>=0XA1 && (unsigned char)ch2 <= 0XFE)
					{
						this->context[count++]=key;
						this->context[count++]=ch2;
						this->context[count]='\0';
						if(this->status == 0)
						{
							putch('*');
						}
						else if(this->status == 1)
						{
							printf("%c%c",key,ch2);
						}
					}
				}
				// Ӣ����ĸ
				else if((key>='a'&&key<='z')||(key>='A'&&key<='Z'))
				{
					this->context[count++]=key;
					this->context[count]='\0';
					if(this->status==0)
					{
						putch('*');
					}
					else if(this->status==1)
					{
						putch(key);
					}
				}
			}
			// inputType==6��֧�����ġ�Ӣ�ĺ�����
			else if(this->inputType == 6)
			{
				// ����˫�ֽ��ַ�
				if((unsigned char)key>=0XA1 && (unsigned char)key <= 0XFE)
				{
					char ch2 = getch();
					if ((unsigned char)ch2>=0XA1 && (unsigned char)ch2 <= 0XFE)
					{
						this->context[count++]=key;
						this->context[count++]=ch2;
						this->context[count]='\0';
						if(this->status == 0)
						{
							putch('*');
						}
						else if(this->status == 1)
						{
							printf("%c%c",key,ch2);
						}
					}
				}
				// Ӣ�ĺ�����
				else if((key>='a'&&key<='z')||(key>='A'&&key<='Z')||(key>='0'&& key<='9') || key == '.')
				{
					this->context[count++]=key;
					this->context[count]='\0';
					if(this->status==0)
					{
						putch('*');
					}
					else if(this->status==1)
					{
						putch(key);
					}
				}
			}
		}
	}
}

// maxLength
	void CEdit::setmaxLength(int maxLength)
	{
		this->maxLength = maxLength;
	}
	int CEdit::getmaxLength()
	{
		return this->maxLength;
	}
// inputType
	void CEdit::setinputType(int inputType)
	{
		this->inputType = inputType;
	}
	int CEdit::getinputType()
	{
		return this->inputType;
	}
// status
	void CEdit::setstatus(int status)
	{
		this->status = status;
	}
	int CEdit::getstatus()
	{
		return this->status;
	}

