#include "CMStockout.h"

extern User *userCurrent;

CMStockout::CMStockout(int winX,int winY,int winWidth,int winHeight)
	:CWindow(winX,winY,winWidth,winHeight)
{
	this->lab1 = new CLabel(LABEL,43,7,0,0,"��ӭʹ�òֿ��̵��ϵͳ");

	this->btn1 = new CButton(BUTTON,30,13,18,3,"����[1]");
	this->btn2 = new CButton(BUTTON,60,13,18,3,"�����¼[2]");
	this->btn3 = new CButton(BUTTON,30,18,18,3,"����[Esc]");

	this->addControl(lab1);// 0
	this->addControl(btn1);// 1
	this->addControl(btn2);// 2
	this->addControl(btn3);// 3

}
CMStockout::~CMStockout()
{

}

int CMStockout::doaction()
{
	if(flag == -1)
	{
		return 9; // ����ESC�˳������
	}
	else if(flag == 1)
	{
		return 10 ;
	}
	else if(flag == 2)
	{
		return 9;
	}
	else if(flag == 3)
	{
	//	userCurrent = NULL;
		return 3;
	}
	return -1;

}
