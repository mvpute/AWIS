#include "User.h"


User::User()
{
	// ��ʼ����Ա����
	username[0] = '\0';
	password[0] = '\0';
	role = 0;
	userID = 0;
}

User::User(int role,int userID,const char* username, const char* password)
{

	this->role = role;
	this->userID = userID;

	if (username != NULL)
	{
		strcpy(this->username, username); // ��һ��λ�ø���ֹ��
		this->username[19] = '\0'; // ȷ���ַ�����ֹ
	}
	else
	{
		this->username[0] = '\0';
	}

	if (password != NULL)
	{
		strcpy(this->password, password); // ��һ��λ�ø���ֹ��
		this->password[19] = '\0'; // ȷ���ַ�����ֹ
	}
	else
	{
		this->password[0] = '\0';
	}
}

User::~User()
{

}

char* User::getUsername()
{
	return username;
}

void User::setUsername(const char* username)
{
	if (username != NULL)
	{
		strcpy(this->username, username);
		this->username[19] = '\0';
	}
}

char* User::getPassword()
{
	return password;
}

void User::setPassword(const char* password)
{
	if (password != NULL)
	{
		strcpy(this->password, password);
		this->password[19] = '\0';
	}
}

int User::getRole()
{
	return role;
}
int User::setRole(int role)
{
	this->role = role;
}

int User::getUserID()
{
    return userID;
}

void User::setUserID(int userID)
{
    this->userID = userID;
}






