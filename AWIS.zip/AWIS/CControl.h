#ifndef  CCONTROL_H
#define  CCONTROL_H

#include <string.h>
#include "CTool.h"
#include <iostream>
using namespace std;

#define LABEL 1
#define BUTTON 2
#define EDIT 3

class CControl
{
	public:
		CControl(int type,int x,int y,int width,int height,const char *context,bool isDraw);
		~CControl();

		void setType(int type);
		int getType();
		
		void setx(int x);
		int getx();

		void sety(int y);
		int gety();

		void setwidth(int width);
		int getwidth();

		void setheight(int height);
		int getheight();

		void setcontext(const char *context);
		const char* getcontext() const ;
		
		void setIsDraw(bool isDraw); 
		bool getIsDraw();
		// ��ʾ���� ���麯�� 
		virtual void showControl()=0;
	protected:
		int type;
		int x;
		int y;
		int width;
		int height;
		char context[60];
		bool isDraw; // true�����ƿؼ����ݣ�false�����ƿո񸲸�
};

#endif

