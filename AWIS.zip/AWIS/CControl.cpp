#include "CControl.h"

CControl::CControl(int type,int x,int y,int width,int height,const char *context,bool isDraw)
{
	this->type=type;		// ��ʼ���ؼ�����
	this->x=x;
	this->y=y;
	this->width = width;
	this->height=height;
	strcpy(this->context,context);
	this->isDraw = isDraw;
}
CControl::~CControl()
{

}

void CControl::setType(int type)
{
	this->type = type;
}
int CControl::getType()
{
	return this->type;
}
void CControl::setx(int x)
{
	this->x = x;
}
int CControl::getx()
{
	return this->x;
}

void CControl::sety(int y)
{
	this->y = y;
}
int CControl::gety()
{
	return this->y;
}

void CControl::setwidth(int width)
{
	this->width = width;
}
int CControl::getwidth()
{
	return this->width;
}

void CControl::setheight(int height)
{
	this->height = height;
}
int CControl::getheight()
{
	return this->height;
}

void CControl::setcontext(const char *context)
{
	strcpy(this->context,context);
}
const char *CControl::getcontext()const
{
	return this->context;
}

void CControl::setIsDraw(bool isDraw)
{
	this->isDraw = isDraw;
}
bool CControl::getIsDraw() 
{
	return isDraw;
}


