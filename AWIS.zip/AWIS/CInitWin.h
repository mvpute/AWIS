#ifndef CINITWIN_H
#define CINITWIN_H
#include "CWindow.h"
#include <stdlib.h>
class CInitWin:public CWindow
{
	public:
		CInitWin(int winX,int winY,int winWidth,int winHeight);
		~CInitWin();

		int doaction();
	private:
		CControl *btn1;
		CControl *btn2;
		CControl *btn3;
		CControl *lab1;
		CControl *lab2;
};

#endif

