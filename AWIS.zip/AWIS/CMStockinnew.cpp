#include "CMStockinnew.h"
extern User *userCurrent;
extern vector<User*>* uservec;
extern vector<Product*> * Pdvec;

CMStockinnew::CMStockinnew(int winX,int winY,int winWidth,int winHeight)
	:CWindow(winX,winY,winWidth,winHeight)
{
	this->lab1 = new CLabel(LABEL,43,7,0,0,"��ӭʹ�òֿ��̵��ϵͳ");
	this->lab2 = new CLabel(LABEL,27,11,0,0,"��Ʒ��ţ�");
	this->lab3 = new CLabel(LABEL,27,14,0,0,"��Ʒ���ƣ�");
	this->lab4 = new CLabel(LABEL,27,17,0,0,"��Ʒ���ͣ�");
	this->lab5 = new CLabel(LABEL,27,20,0,0,"��Ʒ�۸�");
	this->lab6 = new CLabel(LABEL,27,23,0,0,"��λ��ţ�");

	this->edit1 = new CEdit(EDIT,40,13,30,3,"",10,6,1);
	this->edit2 = new CEdit(EDIT,40,16,30,3,"",10,6,1);
	this->edit3 = new CEdit(EDIT,40,19,30,3,"",10,1,1);
	this->edit4 = new CEdit(EDIT,40,22,30,3,"",10,3,1);

	this->btn1 = new CButton(BUTTON,30,26,15,3,"ȷ��[Enter]");
	this->btn2 = new CButton(BUTTON,66,26,15,3,"ȡ��[Esc]");
	this->addControl(lab1);// 0
	this->addControl(lab2);// 1
	this->addControl(lab3);// 2
	this->addControl(lab4);// 3
	this->addControl(lab5);// 4
	this->addControl(lab6);// 5
	this->addControl(edit1);//6
	this->addControl(edit2);//7
	this->addControl(edit3);//8
	this->addControl(edit4);//9
	this->addControl(btn1);// 10
	this->addControl(btn2);// 11


}
CMStockinnew::~CMStockinnew()
{

}

void CMStockinnew::paintWindow()
{
	CWindow::paintWindow();
	CTool::gotoxy(43,11);
	int nextNum = Pdvec->size() + 1;
	char buffer[20];
	sprintf(buffer, "PD%03d", nextNum);
	cout<<buffer<<endl;
}


int CMStockinnew::doaction()
{
	if(flag == 10)
	{
		int nextNum = Pdvec->size() + 1;
		char buffer[20];
		sprintf(buffer, "PD%03d", nextNum);
		const char* newpdID = buffer;
		const char* newpdName = this->arr[6]->getcontext();
		const char* newpdType = this->arr[7]->getcontext();
		double newpdPrice = atof(this->arr[8]->getcontext());
		
		int newpdNum = 0;
		const char* pdCId = this->arr[9]->getcontext();
		if(strcmp(this->arr[7]->getcontext(), "") == 0 || strcmp(this->arr[8]->getcontext(), "") == 0)
		{
			CTool::gotoxy(40,25);
			cout<<"��Ʒ���ơ���Ʒ���Ͳ���Ϊ��"<<endl;
			Sleep(1500);
			return 8;
		}
		else
		{
			Product *newPd = new Product(newpdID,newpdName,newpdType,newpdPrice,newpdNum,pdCId);
			Pdvec->push_back(newPd);
			CFileP filep;
			filep.productFileWrite(newPd);
			CTool::gotoxy(40,25);
			cout<<"���ӳɹ�"<<endl;
			Sleep(1500);
			return 7;
		}

	}
	else if(flag == 11)
	{
		return 6;
	}
	return -1;
}

