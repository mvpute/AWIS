#ifndef USER_H
#define USER_H
#include <string.h>
class User  
{
public:
    User();
    User(int role,int userID,const char* username,const char* password);
    ~User();
    
    char* getUsername();
    void setUsername(const char* username);
    
    char* getPassword();
    void setPassword(const char* password);
    
    int getRole();
    int setRole(int role);
    int getUserID();
    void setUserID(int userID);
private:
    char username[20];
    char password[20];
    int role;
    int userID;
};

#endif

