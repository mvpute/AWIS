#ifndef CMSTOCKINONE_H
#define CMSTOCKINONE_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "Product.h"
#include <string.h> 
#include <vector> 
#include "CFileP.h" 
//#include "CMStockintwo.h"
class CMStockinone : public CWindow
{
	public:
		CMStockinone(int winX,int winY,int winWidth,int winHeight);
		~CMStockinone();
	
		int doaction();
		void paintWindow();
		int LittleWin();				
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *lab3;
		CControl *lab4;
		CControl *lab5;
		CControl *edit1;
		CControl *edit2;
		CControl *btn1;
		CControl *btn2;
		CControl *btn3;
		CControl *btn4;
		CControl *btn5;

};






#endif
