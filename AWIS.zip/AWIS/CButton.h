#ifndef CBUTTON_H
#define CBUTTON_H
#include <string.h>
#include <iostream>
#include "CTool.h"
#include "CControl.h" 
using namespace std;

class CButton:public CControl
{
	public:
		CButton(int type,int x,int y,int width,int height,const char *context,bool isDraw = true);
		~CButton();
		void showControl();

};
#endif

