#ifndef CMSTOCKOUT_H
#define CMSTOCKOUT_H

#include "CWindow.h"
#include <stdlib.h>

class CMStockout : public CWindow
{
	public:
		CMStockout(int winX,int winY,int winWidth,int winHeight);
		~CMStockout();

		int doaction();
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *btn1;
		CControl *btn2;
		CControl *btn3;

};






#endif
