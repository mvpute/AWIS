#include "CInitWin.h"

CInitWin::CInitWin(int winX,int winY,int winWidth,int winHeight)
	:CWindow(winX,winY,winWidth,winHeight)
{
	// init��ʼ����
	this->btn1 = new CButton(BUTTON,43,11,18,3,"��       ¼ ");
	this->btn2 = new CButton(BUTTON,43,15,18,3,"ע       ��");
	this->btn3 = new CButton(BUTTON,43,19,18,3,"��       ��");
	this->lab1 = new CLabel (LABEL,68,23,0,0,"ѧ�ţ�OMO250735");
	this->lab2 = new CLabel (LABEL,45,8,0,0,"�ֿ��̵����Ŀ");
	this->addControl(btn1);// 0
	this->addControl(btn2);// 1
	this->addControl(btn3);// 2
	this->addControl(lab1);// 3
	this->addControl(lab2);// 4
}
CInitWin::~CInitWin()
{

}
int CInitWin::doaction()
{
	if(flag == -1)
	{
		return 0; // ����ESC�˳������
	}
	else if(flag == 0)
	{
		return 1;
	}
	else if(flag == 1)
	{
		return 2;
	}
	else if(flag == 2)
	{
		exit(0);
	}
	
	return -1; 
}

