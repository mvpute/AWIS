#include "CLabel.h"

CLabel::CLabel(int type,int x,int y,int width,int height,const char *context, bool isDraw)
	:CControl(type,x,y,width,height,context,isDraw)
{

}
CLabel::~CLabel()
{

}

void CLabel::showControl()
{
	CTool::gotoxy(this->x,this->y);
	cout<<this->context<<endl;
}


