#ifndef CPTAKENEW_H
#define CPTAKENEW_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "Product.h"
#include <string.h>
#include <vector>
#include <map>
#include <time.h>
#include "CFileP.h"
#include <io.h>
#include "CPRecord.h"

class CPTakenew : public CWindow
{
	public:
		CPTakenew(int winX,int winY,int winWidth,int winHeight);
		~CPTakenew();

		int doaction();
		void paintWindow();
		string getCurrentDate();
		void autocheckNum();
		int getMaxSeqFromFile(const string& currentDate);
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *lab3;
		CControl *lab4;

		CControl *edit1;
		CControl *edit2;
		CControl *btn1;
		CControl *btn2;
		CControl *btn3;
		CControl *btn4;

};






#endif
