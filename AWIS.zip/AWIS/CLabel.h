#ifndef CLABEL_H
#define CLABEL_H

#include <string.h>
#include <iostream>
#include "CTool.h"
#include "CControl.h" 
using namespace std;

class CLabel:public CControl
{	
	public:
		CLabel(int type,int x,int y,int width,int height,const char *context,bool isDraw = true);
		~CLabel();

		void showControl();

};
#endif
