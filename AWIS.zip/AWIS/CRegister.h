#ifndef CREGISTER_H
#define CREGISTER_H

#include <stdio.h>
#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include "CControl.h"
#include "CWindow.h"
#include "User.h"
#include "CTool.h"
#include "CFile.h"
#include <vector>
using namespace std;

class CRegister : public CWindow
{
	public:
		CRegister(int winX, int winY, int winWidth, int winHeight);
		~CRegister();

		int cregisterUser(int role,int useID, const char* username, const char* password, const char* repassword);
		int doaction();
		void paintWindow();
		//void winRun();
		void LittleWin(); 
	private:
		// �ؼ�ָ������
		CControl* lab1;
		CControl* lab2;
		CControl* lab3;
		CControl* lab4;
		CControl* lab5;
		CControl* lab6;
		CControl* edit1;
		CControl* edit2;
		CControl* edit3;

		CControl* button1;
		CControl* button2;
		CControl* button3;
		CControl* button4;
		CControl* button5;
		
		int role;

};
#endif


