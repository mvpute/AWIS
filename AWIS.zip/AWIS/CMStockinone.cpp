#include "CMStockinone.h"


extern User *userCurrent;
extern vector<User*>* uservec;
extern vector<Product*> * Pdvec;
int flag1 = 0; // ִ�в�ѯ���жϵ�
int currentI = -1;

CMStockinone::CMStockinone(int winX,int winY,int winWidth,int winHeight)
	:CWindow(winX,winY,winWidth,winHeight)
{
	this->lab1 = new CLabel(LABEL,43,6,0,0,"��ӭʹ�òֿ��̵��ϵͳ");
	this->lab2 = new CLabel(LABEL,27,11,0,0,"��������Ʒ��ţ�");
	this->lab3 = new CLabel(LABEL,59,15,0,0,"�������������[1-10000]��");
	this->edit1 = new CEdit(EDIT,44,10,25,3,"",10,3,1);
	this->edit2 = new CEdit(EDIT,59,17,25,3,"",10,3,1);
	this->btn1 = new CButton(BUTTON,70,10,10,3,"��ѯ");
	this->btn2 = new CButton(BUTTON,58,24,15,3,"ȷ��[Enter]");
	this->btn3 = new CButton(BUTTON,74,24,15,3,"ȡ��[Esc]");
	this->addControl(lab1);// 0
	this->addControl(lab2);// 1
	this->addControl(lab3);// 2
	this->addControl(edit1);//3
	this->addControl(btn1);// 4
	this->addControl(edit2);//5
	this->addControl(btn2);// 6
	this->addControl(btn3);// 7
}

CMStockinone::~CMStockinone()
{

}


void CMStockinone::paintWindow()
{
	CWindow::paintWindow();
	CTool::paintBorder(22,13,35,14);
	CTool::gotoxy(25,15);
	cout<<"��Ʒ����:"<<endl;
	CTool::gotoxy(25,17);
	cout<<"��Ʒ���ͣ�"<<endl;
	CTool::gotoxy(25,19);
	cout<<"��Ʒ�۸�"<<endl;
	CTool::gotoxy(25,21);
	cout<<"�������:"<<endl;
	CTool::gotoxy(25,23);
	cout<<"��λ��ţ�"<<endl;
	if(flag1 == 1)
	{
		CTool::gotoxy(36,15);
		cout<<Pdvec->at(currentI)->getpdName()<<endl;
		CTool::gotoxy(36,17);
		cout<<Pdvec->at(currentI)->getpdType()<<endl;
		CTool::gotoxy(36,19);
		printf("%.02fԪ",Pdvec->at(currentI)->getpdPrice());
		CTool::gotoxy(36,21);
		cout<<Pdvec->at(currentI)->getpdNum()<<endl;
		CTool::gotoxy(36,23);
		cout<<Pdvec->at(currentI)->getpdCId()<<endl;
	}
}

int CMStockinone::LittleWin()
{
	CTool::paintBorder(40,10,30,16);
	this->lab4 = new CLabel(LABEL,42,12,0,0,"��ʾ:");
	this->lab5 = new CLabel(LABEL,45,14,0,0,"δ�ҵ���Ӧ����Ʒ");
	this->btn4 = new CButton(BUTTON,48,17,15,3,"��������[1]");
	this->btn5 = new CButton(BUTTON,48,20,15,3,"������Ʒ[2]");

	this->addControl(lab4);// 8
	this->addControl(lab5);// 9
	this->addControl(btn4);// 10
	this->addControl(btn5);// 11
	this->lab4->showControl();
	this->lab5->showControl();
	this->btn4->showControl();
	this->btn5->showControl();
	int iKey;
	int i=10;
	CTool::gotoxy(this->arr[i]->getx()+3+strlen((this->arr[i]->getcontext())),this->arr[i]->gety()+1);
	while(1)
	{
		iKey = CTool::getKey();
		switch(iKey)
		{
			case KEY_UP:
				i--;
				if(i<10)
				{
					i=11;
				}

				CTool::gotoxy(this->arr[i]->getx() + 3 + strlen(this->arr[i]->getcontext()), this->arr[i]->gety() + 1);
				break;
			case KEY_DOWN:
				i++;
				if(i>11)
				{
					i=10;
				}
				CTool::gotoxy(this->arr[i]->getx() + 3 + strlen(this->arr[i]->getcontext()), this->arr[i]->gety() + 1);
				break;
			case KEY_ESC:
				// ���ñ�־Ϊ-1����ʾȡ����
				this->flag = -1;
				return 7;// �˳���Ϣѭ��
			case KEY_ENTER:
				if(this->arr[i]->getType() == BUTTON)
				{
					this->flag = i; // ��¼��ǰ��ť�����������ں���ҵ������
				}
				this->arr[this->count--]=NULL;
				this->arr[this->count--]=NULL;
				this->arr[this->count--]=NULL;
				this->arr[this->count--]=NULL;
				if(flag == 10)
				{
					return 7;
				}
				else if(flag == 11)
				{
					return 8;
				}
		}
	}
}

int CMStockinone::doaction()
{
	if(flag == -1)
	{
		return 6; // ����ESC�˳������
	}
	else if(flag == 4) // ��ѯ
	{
		flag1 = 0;
		currentI = -1;

		string inputPdID = this->edit1->getcontext();
		this->paintWindow();
		this->edit1->setcontext(inputPdID.c_str());
		this->edit1->showControl();
		if(!inputPdID.empty())
		{

			for (int i = 0; i < Pdvec->size(); i++)
			{
				if(Pdvec->at(i)->getpdID() == inputPdID)
				{
					currentI = i;
					flag1 = 1;
					break;
				}
			}
		}
		if(currentI == -1)
		{
			int res = LittleWin();
			currentI = -2;
			return res;
		}
		else
		{
			return 7;
		}
	}
	else if(flag == 6) // ȷ��
	{
		if(currentI<0)
		{
			return 7;
		}
		int addNum;
		int oldNum;
		addNum = atoi(this->edit2->getcontext());
		oldNum = Pdvec->at(currentI)->getpdNum();
		if(addNum>10000 || addNum<1)
		{
			CTool::gotoxy(63, 28);
			cout<<"����Ϊ[1-10000]"<<endl;
			this->edit2->setcontext("");
			Sleep(2000);
		}
		else
		{
			if(currentI>=0)
			{
				Pdvec->at(currentI)->setpdNum(addNum+oldNum);
				CFileP fileP; // ʵ������Ʒ�ļ���������
				fileP.updateProductFile(Pdvec);
				CTool::gotoxy(63, 28);
				cout<<"���ɹ�"<<endl;
				this->edit2->setcontext("");
				Sleep(2000);
			}
		}
		return 7;
	}
	else if(flag == 7) // ȡ��
	{
		return 6;
	}
	return -1;
}

