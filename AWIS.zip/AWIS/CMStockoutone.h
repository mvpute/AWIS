#ifndef CMSTOCKOUTONE_H
#define CMSTOCKOUTONE_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "Product.h"
#include <string.h> 
#include <vector> 
#include "CFileP.h"
class CMStockoutone : public CWindow
{
	public:
		CMStockoutone(int winX,int winY,int winWidth,int winHeight);
		~CMStockoutone();
	
		int doaction();
		void paintWindow();

						
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *lab3;
		CControl *lab4;
		CControl *lab5;
		CControl *lab6;

		CControl *edit1;
		CControl *edit2;
		CControl *btn1;
		CControl *btn2;
		CControl *btn3;

};






#endif
