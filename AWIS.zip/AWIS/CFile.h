#ifndef CFILE_H
#define CFILE_H
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "User.h" 
using namespace std;

class CFile
{
	public:
		void userFileWrite(User * user);
		vector<User *> * userFileRead();
		bool isUserIdExists(int userId);

};




#endif
