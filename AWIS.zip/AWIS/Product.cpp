#include "Product.h"


Product::Product()
{
	// ��ʼ����Ա����
	pdID[0] = '\0';
	pdName[0] = '\0';
	pdType[0] = '\0';
	pdPrice = 0.00;
	pdNum = 0;
	pdCId[0] = '\0';
}

Product::Product(const char* pdID,const char* pdName,const char* pdType,double pdPrice,int pdNum,const char* pdCId)
{
	// 1
	if (pdID != NULL)
	{
		strcpy(this->pdID, pdID); // ��һ��λ�ø���ֹ��
		this->pdID[19] = '\0'; // ȷ���ַ�����ֹ
	}
	else
	{
		this->pdID[0] = '\0';
	}
	// 2
	if (pdName != NULL)
	{
		strcpy(this->pdName, pdName); // ��һ��λ�ø���ֹ��
		this->pdName[19] = '\0'; // ȷ���ַ�����ֹ
	}
	else
	{
		this->pdName[0] = '\0';
	}
	// 3
	if (pdType != NULL)
	{
		strcpy(this->pdType, pdType); // ��һ��λ�ø���ֹ��
		this->pdType[19] = '\0'; // ȷ���ַ�����ֹ
	}
	else
	{
		this->pdType[0] = '\0';
	}
	// 4
	if (pdCId != NULL)
	{
		strcpy(this->pdCId, pdCId); // ��һ��λ�ø���ֹ��
		this->pdCId[19] = '\0'; // ȷ���ַ�����ֹ
	}
	else
	{
		this->pdCId[0] = '\0';
	}

	this->pdPrice = pdPrice;
	this->pdNum = pdNum;
}

Product::~Product()
{

}

// pdID
char* Product::getpdID()
{
	return pdID;
}
void Product::setpdID(const char* pdID)
{
	if (pdID != NULL)
	{
		strcpy(this->pdID, pdID);
		this->pdID[19] = '\0';
	}
}
// pdName
char* Product::getpdName()
{
	return pdName;
}
void Product::setpdName(const char* pdName)
{
	if (pdName != NULL)
	{
		strcpy(this->pdName, pdName);
		this->pdName[19] = '\0';
	}
}
// pdType
char* Product::getpdType()
{
	return pdType;
}
void Product::setpdType(const char* pdType)
{
	if (pdType != NULL)
	{
		strcpy(this->pdType, pdType);
		this->pdType[19] = '\0';
	}
}
// pdPrice
double Product::getpdPrice()
{
	return pdPrice;
}
void Product::setpdPrice(double pdPrice)
{
	this->pdPrice = pdPrice;
}
// pdNum
int Product::getpdNum()
{
	return pdNum;
}
void Product::setpdNum(int pdNum)
{
	this->pdNum = pdNum;
}
// pdCId
char* Product::getpdCId()
{
	return pdCId;
}
void Product::setpdCId(const char* pdCId)
{
	if (pdCId != NULL)
	{
		strcpy(this->pdCId, pdCId);
		this->pdCId[19] = '\0';
	}
}





