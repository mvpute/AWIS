#ifndef CPREVERSALTWO_H
#define CPREVERSALTWO_H

#include "CTool.h"
#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "Product.h"
#include <string.h>
#include <vector>
#include <map>
#include <time.h>
#include "CFileP.h"
#include "CPRecord.h"
#include "CFilePR.h"
class CPReversaltwo : public CWindow
{
	public:
		CPReversaltwo(int winX,int winY,int winWidth,int winHeight);
		~CPReversaltwo();

		int doaction();
		void paintWindow();
		void winRun();
		void showCheck();
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *lab3;
		CControl *lab4;
		CControl *btn1;
		CControl *btn2;

};






#endif
