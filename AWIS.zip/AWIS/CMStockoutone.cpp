#include "CMStockoutone.h"


extern User *userCurrent;
extern vector<User*>* uservec;
extern vector<Product*> * Pdvec;


int flag2 = 0; // ִ�в�ѯ���жϵ�
int currentII = -1;

CMStockoutone::CMStockoutone(int winX,int winY,int winWidth,int winHeight)
	:CWindow(winX,winY,winWidth,winHeight)
{
	this->lab1 = new CLabel(LABEL,43,6,0,0,"��ӭʹ�òֿ��̵��ϵͳ");
	this->lab2 = new CLabel(LABEL,27,11,0,0,"��������Ʒ��ţ�");
	this->lab3 = new CLabel(LABEL,59,15,0,0,"�������������[1-10000]��");
	this->edit1 = new CEdit(EDIT,44,10,25,3,"",10,3,1);
	this->edit2 = new CEdit(EDIT,59,17,25,3,"",10,3,1);
	this->btn1 = new CButton(BUTTON,70,10,10,3,"��ѯ");
	this->btn2 = new CButton(BUTTON,58,24,15,3,"ȷ��[Enter]");
	this->btn3 = new CButton(BUTTON,74,24,15,3,"ȡ��[Esc]");
	this->addControl(lab1);// 0
	this->addControl(lab2);// 1
	this->addControl(lab3);// 2
	this->addControl(edit1);//3
	this->addControl(btn1);// 4
	this->addControl(edit2);//5
	this->addControl(btn2);// 6
	this->addControl(btn3);// 7
}

CMStockoutone::~CMStockoutone()
{

}


void CMStockoutone::paintWindow()
{
	CWindow::paintWindow();
	CTool::paintBorder(22,13,35,14);
	CTool::gotoxy(25,15);
	cout<<"��Ʒ����:"<<endl;
	CTool::gotoxy(25,17);
	cout<<"��Ʒ���ͣ�"<<endl;
	CTool::gotoxy(25,19);
	cout<<"��Ʒ�۸�"<<endl;
	CTool::gotoxy(25,21);
	cout<<"�������:"<<endl;
	CTool::gotoxy(25,23);
	cout<<"��λ��ţ�"<<endl;
	if(flag2 == 1)
	{
		CTool::gotoxy(36,15);
		cout<<Pdvec->at(currentII)->getpdName()<<endl;
		CTool::gotoxy(36,17);
		cout<<Pdvec->at(currentII)->getpdType()<<endl;
		CTool::gotoxy(36,19);
		printf("%.02fԪ",Pdvec->at(currentII)->getpdPrice());
		CTool::gotoxy(36,21);
		cout<<Pdvec->at(currentII)->getpdNum()<<endl;
		CTool::gotoxy(36,23);
		cout<<Pdvec->at(currentII)->getpdCId()<<endl;
	}
}


int CMStockoutone::doaction()
{
	if(flag == -1)
	{
		return 9; // ����ESC�˳������
	}
	else if(flag == 4) // ��ѯ
	{
		flag2 = 0;
		currentII = -1;

		string inputPdID = this->edit1->getcontext();
		this->paintWindow();
		this->edit1->setcontext(inputPdID.c_str());
		this->edit1->showControl();
		if(!inputPdID.empty())
		{

			for (int i = 0; i < Pdvec->size(); i++)
			{
				if(Pdvec->at(i)->getpdID() == inputPdID)
				{
					currentII = i;
					flag2 = 1;
					break;
				}
			}
		}
		if(currentII == -1)
		{
			currentII = -2;
			CTool::gotoxy(60,21);
			cout<<"δ�ҵ���Ʒ��Ϣ"<<endl;
			CTool::gotoxy(60,22);
			cout<<"����������"<<endl;
			Sleep(1500);
		}
		return 10;
	}
	else if(flag == 6)
	{
		if(currentII<0)
		{
			return 10;
		}
		
		int reduceNum;
		int oldNum;
		reduceNum = atoi(this->edit2->getcontext());
		oldNum = Pdvec->at(currentII)->getpdNum();
		if(reduceNum>10000 || reduceNum<1)
		{
			CTool::gotoxy(63, 28);
			cout<<"����Ϊ[1-10000]"<<endl;
			this->edit2->setcontext("");
			Sleep(2000);
			return 10;
		}
		else
		{
			if(currentII>=0)
			{
				if(reduceNum>oldNum)
				{
					CTool::gotoxy(61, 28);
					cout<<"�����������ڸ���Ʒ�Ŀ������"<<endl;
					Sleep(2000);
					return 10;
				}
				else
				{
					Pdvec->at(currentII)->setpdNum(oldNum-reduceNum);
					CFileP fileP; // ʵ������Ʒ�ļ���������
					fileP.updateProductFile(Pdvec);
					CTool::gotoxy(63, 28);
					cout<<"����ɹ�"<<endl;
					this->edit2->setcontext("");
					Sleep(2000);
					return 10;
				}
			}
			else
			{
				return 10;
			}
		}
		return 10;

	}
	else if(flag == 7) // �˳�
	{
		flag2 = 0;
		currentII = -1;
		this->edit1->setcontext("");
		this->edit2->setcontext("");
		return 9;
	}

	return -1;

}

