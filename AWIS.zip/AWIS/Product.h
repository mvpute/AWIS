#ifndef PRODUCT_H
#define PRODUCT_H
#include <string.h>
class Product
{
	public:
		Product();
		Product(const char* pdID,const char* pdName,const char* pdType,double pdPrice,int pdNum,const char* pdCId);
		~Product();

		char* getpdID();
		void setpdID(const char* pdID);

		char* getpdName();
		void setpdName(const char* pdName);

		char* getpdType();
		void setpdType(const char* pdType);
		
		double getpdPrice();
		void setpdPrice(double pdPrice);
		
		int getpdNum();
		void setpdNum(int pdNum);
		
		char* getpdCId();
		void setpdCId(const char* pdCId);
	private:
		char pdID[20];
		char pdName[20];
		char pdType[20];
		double pdPrice;
		int pdNum;
		char pdCId[20];
};

#endif

