#ifndef CMSTOCKINNEW_H
#define CMSTOCKINNEW_H

#include "CWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include "Product.h"
#include <string.h>
#include <vector>
#include "CFileP.h"
class CMStockinnew : public CWindow
{
	public:
		CMStockinnew(int winX,int winY,int winWidth,int winHeight);
		~CMStockinnew();
		void paintWindow();
		int doaction();

	//	void paintWindow();
//		void winRun();

	private:
		CControl *lab1;
		CControl *lab2;
		CControl *lab3;
		CControl *lab4;
		CControl *lab5;
		CControl *lab6;
		CControl *edit1;
		CControl *edit2;
		CControl *edit3;
		CControl *edit4;
		CControl *btn1;
		CControl *btn2;

};

#endif
