#ifndef CMINIT_H
#define CMINIT_H

#include "CWindow.h"
#include <stdlib.h>

class CMInit : public CWindow
{
	public:
		CMInit(int winX,int winY,int winWidth,int winHeight);
		~CMInit();

		int doaction();
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *btn1;
		CControl *btn2;
		CControl *btn3;
		CControl *btn4;
		CControl *btn5;
		CControl *btn6;

};






#endif
