#include "CButton.h"

CButton::CButton(int type,int x,int y,int width,int height,const char *context, bool isDraw)
:CControl(type,x,y,width,height,context,isDraw) 
{

}
CButton::~CButton()
{
	
}
void CButton::showControl()
{
	CTool::paintBorder(this->x,this->y,this->width,this->height);
	CTool::gotoxy(this->x+3,this->y+1);
	cout<<this->context<<endl;
}




