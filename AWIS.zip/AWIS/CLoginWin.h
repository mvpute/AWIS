#ifndef  CLOGINWIN_H
#define  CLOGINWIN_H
#include "CWindow.h"
#include "User.h"
#include "CTool.h"
#include <string.h>
#include <stdlib.h>
#include <vector>
using namespace std;

class CLoginWin : public CWindow
{
	public:
		CLoginWin(int winX,int winY,int winWidth,int winHeight);
		~CLoginWin();

		int doaction();
		// �ɹ� ���ؽ�ɫ1��2��3
		// ʧ�� ���� 0 �˺Ż������  -1 û���˺�
		int loginCheck(int inputUserID, const char* inputPass);
	private:
		CControl *lab1;
		CControl *lab2;
		CControl *lab3;
		CControl *edit1;
		CControl *edit2;
		CControl *button1;
		CControl *button2;
};




#endif


